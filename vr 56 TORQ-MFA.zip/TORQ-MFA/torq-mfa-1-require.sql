-- =====================================================================
-- TORQ — require two-step sign-in (MFA) for every team account
-- Supabase project btsvcxenxtuvrvbgxdpe · run in Supabase → SQL Editor
--
-- FILE 1 of 2. Run AFTER the updated site files are live on GitHub
-- (otherwise the old pages will just show empty data). Safe to re-run.
-- Nobody is logged out by this file.
-- =====================================================================


-- ---------------------------------------------------------------------
-- STEP 1 · Lock team data behind MFA
-- A signed-in team session that hasn't entered its 6-digit code (aal1)
-- can no longer read or change anything. Public visitors (the anon role:
-- car submissions, sponsor/ambassador forms, voting, check-in passes,
-- job applications) are NOT affected.
-- ---------------------------------------------------------------------
create or replace function public.torq_assert_mfa() returns void
language plpgsql stable as $f$
begin
  if coalesce(auth.jwt()->>'aal','') <> 'aal2' then
    raise exception 'Two-step sign-in required' using errcode = '42501';
  end if;
end $f$;

do $$
declare t record; f record; def text; n int := 0; skipped text := '';
begin
  -- every public table that already has row-level security
  for t in select schemaname, tablename from pg_tables
           where schemaname = 'public' and rowsecurity loop
    execute format('drop policy if exists torq_require_mfa on %I.%I', t.schemaname, t.tablename);
    execute format($p$create policy torq_require_mfa on %I.%I as restrictive for all to authenticated
                     using ((select auth.jwt()->>'aal') = 'aal2')
                     with check ((select auth.jwt()->>'aal') = 'aal2')$p$, t.schemaname, t.tablename);
    n := n + 1;
  end loop;
  raise notice 'MFA required on % tables', n;

  -- warn about tables with no row-level security at all (open to anyone with the public key)
  for t in select tablename from pg_tables where schemaname = 'public' and not rowsecurity loop
    raise warning 'Table public.% has row-level security OFF — it is not protected', t.tablename;
  end loop;

  -- team-only database functions: refuse unless the caller passed MFA
  for f in select p.oid, p.proname, l.lanname from pg_proc p
           join pg_namespace s on s.oid = p.pronamespace
           join pg_language l on l.oid = p.prolang
           where s.nspname = 'public'
             and p.proname in ('checkin_list','checkin_lookup','checkin_mark','checkin_set_details',
                               'checkin_set_parking','checkin_parking','vote_results') loop
    def := pg_get_functiondef(f.oid);
    if def like '%torq_require_mfa%' then continue; end if;
    if f.lanname = 'plpgsql' then
      def := regexp_replace(def, '\mbegin\M', 'begin /* torq_require_mfa */ perform public.torq_assert_mfa();', 'i');
    elsif f.lanname = 'sql' and def ~* 'BEGIN ATOMIC' then
      def := regexp_replace(def, 'BEGIN ATOMIC', 'BEGIN ATOMIC /* torq_require_mfa */ select public.torq_assert_mfa();', 'i');
    elsif f.lanname = 'sql' then
      def := regexp_replace(def, '(AS \$[a-z_]*\$)', '\1 /* torq_require_mfa */ select public.torq_assert_mfa();', 'i');
    else
      skipped := skipped || f.proname || ' ';
      continue;
    end if;
    execute def;
    raise notice 'MFA required on function %', f.proname;
  end loop;
  if skipped <> '' then raise warning 'Not plpgsql, NOT patched (send these names to Claude): %', skipped; end if;
end $$;

-- uploaded files (car photos, résumés, careers media, vote thumbnails)
drop policy if exists torq_require_mfa on storage.objects;
create policy torq_require_mfa on storage.objects as restrictive for all to authenticated
  using ((select auth.jwt()->>'aal') = 'aal2')
  with check ((select auth.jwt()->>'aal') = 'aal2');


-- ---------------------------------------------------------------------
-- STEP 2 · Preview: who has NOT set up MFA yet (nothing changes)
-- ---------------------------------------------------------------------
select u.email, p.name, p.role, u.last_sign_in_at,
       (select count(*) from auth.sessions s where s.user_id = u.id) as active_sessions
from auth.users u
left join public.team_profiles p on p.id = u.id
where not exists (select 1 from auth.mfa_factors f where f.user_id = u.id and f.status = 'verified')
order by p.name nulls last, u.email;
