TORQ — two-step sign-in (MFA) for every team account
=====================================================
Do these in order.

1) UPLOAD THE SITE FILES (GitHub → repo → Add file → Upload files → drag in → Commit)
   torqevents/torq-portal       → all 7 files in the torq-portal folder
   torqevents/torq-checkin      → torq-checkin/index.html
   torqevents/torq-vote         → torq-vote/index.html
   torqevents/vehiclesubmission → vehiclesubmission/index.html
   Wait ~1 minute for GitHub Pages to update.

2) SET UP YOUR OWN MFA FIRST
   Open portal.torqevents.com, sign in, scan the QR code with an authenticator app,
   type the 6-digit code. (Do this before step 4 so you're never locked out.)

3) SUPABASE → SQL Editor → paste torq-mfa-1-require.sql → Run
   Locks all team data behind MFA and shows the list of people without MFA.
   If it prints a "NOT patched" or "row-level security OFF" warning, send it to Claude.

4) SUPABASE → SQL Editor → paste torq-mfa-2-logout.sql → Run
   Logs those people out on every device. Next sign-in they must scan the QR code.

LOST PHONE: in torq-mfa-2-logout.sql, the "LATER" section resets one person's MFA.
