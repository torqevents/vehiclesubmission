-- =====================================================================
-- TORQ — FILE 2 of 2 · log out everyone who hasn't set up MFA
-- Run AFTER torq-mfa-1-require.sql and AFTER checking its preview list.
-- Ends every session (all devices) for accounts with no verified
-- authenticator. When they sign back in, the QR setup screen appears and
-- they can't get past it until two-step sign-in is on.
-- =====================================================================
-- ---------------------------------------------------------------------
-- STEP 3 · Log those people out on every device
-- Ends every session for accounts with no verified authenticator.
-- When they sign back in, the QR setup screen appears and they can't
-- get past it until MFA is on.
-- ---------------------------------------------------------------------
delete from auth.sessions s
where not exists (select 1 from auth.mfa_factors f where f.user_id = s.user_id and f.status = 'verified');


-- ---------------------------------------------------------------------
-- LATER · Reset someone's MFA (lost phone). They'll get a new QR code
-- at their next sign-in. Replace the email.
-- ---------------------------------------------------------------------
-- delete from auth.sessions    where user_id = (select id from auth.users where email = 'name@torqevents.com');
-- delete from auth.mfa_factors where user_id = (select id from auth.users where email = 'name@torqevents.com');
